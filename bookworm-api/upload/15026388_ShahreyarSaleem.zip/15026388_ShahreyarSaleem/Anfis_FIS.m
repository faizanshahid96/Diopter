origdata = importdata('Skin_NonSkin.txt'); 
inputfromfile  = origdata(:,1:3); 
outputfromfile = origdata (:,4); 

origdata = origdata(randperm(size(origdata,1)),:); 

fisobj=anfis(origdata);  

answ = round(evalfis(origdata(:,1:3),fisobj)); 

same = answ==origdata(:,4); 

counter = sum (same == 1);     

disp(counter/length(origdata)*100);