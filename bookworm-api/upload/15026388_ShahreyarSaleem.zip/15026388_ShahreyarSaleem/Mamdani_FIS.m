data = importdata('Skin_NonSkin.txt');
inputData = data(:,1:3);
outputData = data(:,4);

%RGB to YCBCR using the equation defined in the research paper
YCBCRValues = rgb2ycbcr(inputData);
YCBCRValues = [YCBCRValues(:,1)+16, YCBCRValues(:,2)+128,YCBCRValues(:,3)+128];

%reading the created fuzzy inference system and evaluating it on data
fis  = readfis('FIS.fis');
resultantOutput = evalfis(YCBCRValues,fis);

%checking the result for its accuracy
counter = 0;
for i=1:size(resultantOutput)
    if(resultantOutput(i) <= 0.7)
        resultantOutput(i) = 2;
    else
        resultantOutput(i) = 1;
    end
    if(resultantOutput(i) == outputData(i))
        counter = counter+1;
    end
end

%calculating accuracy or recognition rate
accuracy = counter/size(resultantOutput,1) * 100;